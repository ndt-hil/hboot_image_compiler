This is Bootswitch V1.0.2

This file has been downloaded from:
https://kb.hilscher.com/download/attachments/124829705/BootSwitch_intflash_netXStudio_v1.0.2.bin?version=1&modificationDate=1630996905300&api=v2

It is contained in the following page:
https://kb.hilscher.com/x/CcBwBw
