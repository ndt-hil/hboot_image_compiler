# HIL NXT Hboot Image Compiler APP
The Hboot Image Compiler APP can be used to build hboot images for the APP CPU of a netX.

## Setup
No setup needed before usage.

## Usage
For more information about the tool run the executable with the argument
```
hboot_image_compiler_app.exe -h
```
