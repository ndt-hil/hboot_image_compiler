# HIL NXT Hboot Image Compiler COM
The Hboot Image Compiler COM can be used to build hboot images for the APP CPU of a netX.

## Setup
No setup needed before usage.

## Usage
For more information about the tool run the executable with the argument
```
hboot_image_compiler_com.exe -h
```
